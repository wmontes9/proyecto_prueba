@extends('layouts.app')

@section('content')
    centro de emprendimiento.    
@endsection