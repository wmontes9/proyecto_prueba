@extends('layouts.app')

@section('content')
    Instituto de investigacion.    
@endsection