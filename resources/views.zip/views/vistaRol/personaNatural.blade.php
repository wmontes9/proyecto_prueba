@extends('layouts.app')

@section('content')
    persona natural      
@endsection