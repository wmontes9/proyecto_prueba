<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
<title>Mensaje enviado</title>
</head>
<body>
    Muchas gracias por contactarnos, en breve nos comunicaremos...
</body>
</html>