<div class="item">
    <button type="button" class="button btn btn-warning content-button">
        <i class="far fa-lightbulb "></i> Soluciones 
    </button>
</div>
<div class="item">
    <a href="{{route('retosUsuario')}}" class="button btn btn-warning content-button">
        <i class="fas fa-mountain"></i> Retos 
    </a>
</div>