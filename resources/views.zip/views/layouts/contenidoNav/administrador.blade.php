<!--<div class="item">    
    <a href="{{route('permisos')}}" class="button btn btn-warning content-button">
        <i class="fas fa-unlock-alt"></i> Permisos
    </a>    
</div>-->
<div class="item">
    <a href="{{url('admin/retos')}}" class="button btn btn-warning content-button">
        <i class="fas fa-mountain"></i> Retos
    </a>
</div> 
<div class="item">
    <a href="{{url('admin/solucion')}}" class="button btn btn-warning content-button">
        <i class="far fa-lightbulb "></i> Soluciones 
    </a>
</div>
