<div class="item">
    <button type="button" data-toggle="collapse" data-target="#retosActions" class="button btn btn-warning content-button">
        <i class="fas fa-mountain"></i> Retos 
    </button>
    <div class="sub-list collapse" id="retosActions">
        <div class="item">
            <a href="{{route('retosUsuario')}}" class="button btn content-button">
                <i class="fas fa-user-tie"></i> Mis Retos
            </a>
        </div>
        <div class="item">
            <a href="{{route('retosEmpresa')}}" class="button btn content-button">
                <i class="far fa-building"></i> Retos de Empresa
            </a>
        </div>        
    </div>
</div> 
<!--<div class="item">
    <button type="button" class="button btn btn-warning content-button">
        <i class="far fa-lightbulb "></i> Soluciones 
    </button>
</div>-->